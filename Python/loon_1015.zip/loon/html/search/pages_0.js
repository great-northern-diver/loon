var searchData=
[
  ['getting_20started_113',['Getting started',['../md__r_e_a_d_m_e.html',1,'']]]
];
