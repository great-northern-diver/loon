def UseMethod(funcname, classname, **args):
    return(globals()[classname](args))
