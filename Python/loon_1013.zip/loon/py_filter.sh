#!/bin/bash
doxypypy -a -c $1
