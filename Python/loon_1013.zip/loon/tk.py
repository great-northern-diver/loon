import tkinter
tk = tkinter.Tk()
tk.withdraw() 
tk.eval('lappend auto_path /Users/tedwang/Desktop/loon/Tcl')
tk.eval('package require loon')
